@extends('layouts.dashboard-layout-v2')

@section('fe-content')
<h1>Selamat Datang di Halaman Management</h1>
<p>Chatbot tersedia di pojok kanan bawah untuk membantu Anda.</p>


@endsection
