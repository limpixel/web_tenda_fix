@extends('layouts.dashboard-layout-v2')

@section('head')
   
@endsection

@section('content')
<div class="container mt-4">
    <div class="row">
        <!-- Kolom 1 -->
        <div class="col-md-4 col-sm-6 col-12 mb-3">
            <a id="content__button"  href="{{route('dashboard.home-hero-section.index')}}" class="grid-link ">
                <div class="p-3 border bg-light text-center">Grid 1</div>
            </a>
        </div>
        <!-- Kolom 2 -->
        <div class="col-md-4 col-sm-6 col-12 mb-3">
            <a href="https://example.com/2" class="grid-link">
                <div class="p-3 border bg-light text-center">Grid 2</div>
            </a>
        </div>
        <!-- Kolom 3 -->
        <div class="col-md-4 col-sm-6 col-12 mb-3">
            <a href="https://example.com/3" class="grid-link">
                <div class="p-3 border bg-light text-center">Grid 3</div>
            </a>
        </div>
    </div>
</div>
@endsection