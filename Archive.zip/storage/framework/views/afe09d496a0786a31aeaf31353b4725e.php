<?php $__env->startSection('content'); ?>
<div class="box">
    <div class="box-header">
        <h3 class="box-title">Create Blog</h3>
    </div>
    <div class="box-body">
        <form action="<?php echo e(route('dashboard.blogs.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="image">Image</label>
                <input type="file" name="image" id="image" class="form-control" required onchange="previewImage(event)">
                <img id="image-preview" src="#" alt="Image Preview" style="display: none; width: 200px; margin-top: 10px;">
            </div>
            <div class="form-group">
                <label for="judul_blog">Title</label>
                <input type="text" name="judul_blog" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="desc_blog">Description</label>
                <textarea name="desc_blog" class="form-control" required></textarea>
            </div>
            <div class="form-group">
                <label for="content">Content</label>
                <textarea name="content" class="form-control" required></textarea>
            </div>
            <button type="submit" class="btn btn-success">Save Blog</button>
        </form>
    </div>
</div>

<script>
    function previewImage(event) {
        const image = document.getElementById('image-preview');
        image.src = URL.createObjectURL(event.target.files[0]);
        image.style.display = 'block';
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-layout-v2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/limhalim/Desktop/Laravel-10-roles-and-permissions/resources/views/blogs/create.blade.php ENDPATH**/ ?>