<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6 offset-md-3">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Add New Testimony</h3>
            </div>
            <div class="box-body" style="padding: 20px;">
                <form action="<?php echo e(route('dashboard.about_testimoni_section.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="name_person">Name</label>
                        <input type="text" name="name_person" id="name_person" 
                               class="form-control" placeholder="Enter name" required>
                    </div>
                    <div class="form-group">
                        <label for="testimony_text">Testimony</label>
                        <textarea name="testimony_text" id="testimony_text" 
                                  class="form-control" rows="9" placeholder="Enter testimony" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Save</button>
                    <a href="<?php echo e(route('dashboard.about_testimoni_section.index')); ?>" class="btn btn-secondary">Cancel</a>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-layout-v2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/limhalim/Desktop/Laravel-10-roles-and-permissions/resources/views/about/about_testimony_section/create.blade.php ENDPATH**/ ?>