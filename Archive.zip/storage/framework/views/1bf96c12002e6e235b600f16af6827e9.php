<?php $__env->startSection('content-header'); ?>
    <h1>Home Hero Sections</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="box">
            <div class="box-header d-flex justify-content-between align-items-center mb-2">
                <h3 class="box-title">Hero Section List</h3>
                <?php if($heroSections->count()== 0 ): ?>
                <a href="<?php echo e(route('dashboard.home-hero-section.create')); ?>" class="btn btn-primary pull-right">Add New Hero Section</a>
                <?php endif; ?>
            </div>
            <div class="box-body">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Head Text</th>
                            <th>Title Text</th>
                            <th>Description</th>
                            <th>Image</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $heroSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heroSection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($heroSection->head_text); ?></td>
                                <td><?php echo e($heroSection->title_text); ?></td>
                                <td><?php echo e($heroSection->description); ?></td>
                                <td><img src="<?php echo e(asset('images/home/home_hero_section/' . $heroSection->image)); ?>" alt="Image" width="100"></td>
                                <td>
                                   
                                    <a href="<?php echo e(route('dashboard.home-hero-section.edit', $heroSection->id)); ?>" class="btn btn-warning">Edit</a>
                                    <form action="<?php echo e(route('dashboard.home-hero-section.destroy', $heroSection->id)); ?>" method="POST" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-layout-v2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/limhalim/Desktop/Laravel-10-roles-and-permissions/resources/views/home/home_hero_section/index.blade.php ENDPATH**/ ?>