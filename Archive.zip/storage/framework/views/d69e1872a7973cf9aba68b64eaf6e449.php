<?php $__env->startSection('fe-content'); ?>
<h1>Selamat Datang di Halaman Management</h1>
<p>Chatbot tersedia di pojok kanan bawah untuk membantu Anda.</p>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-layout-v2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/limhalim/Desktop/Laravel-10-roles-and-permissions/resources/views/home.blade.php ENDPATH**/ ?>