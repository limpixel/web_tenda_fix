<?php $__env->startSection('content'); ?>
    <div class="box">
        <div class="box-header d-flex justify-content-between align-items-center mb-2">
            <h3 class="box-title">Blogs</h3>
            <a href="<?php echo e(route('dashboard.blogs.create')); ?>" class="btn btn-primary">Create Blog</a>
        </div>
        <div class="box-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Image</th>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Author</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><img src="<?php echo e(asset('images/blogs/' . $blog->image)); ?>" width="50" height="50" /></td>
                            <td><?php echo e($blog->judul_blog); ?></td>
                            <td><?php echo e($blog->desc_blog); ?></td>
                            <td><?php echo e($blog->user->name); ?></td>
                            <td>
                                <a href="<?php echo e(route('dashboard.blogs.show', $blog)); ?>" class="btn btn-info">View</a>
                                <a href="<?php echo e(route('dashboard.blogs.edit', $blog)); ?>" class="btn btn-warning">Edit</a>
                                <form action="<?php echo e(route('dashboard.blogs.destroy', $blog)); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-layout-v2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/limhalim/Desktop/Laravel-10-roles-and-permissions/resources/views/blogs/index.blade.php ENDPATH**/ ?>