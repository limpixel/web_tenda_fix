<!doctype html>
<html>
<head>
    <title>BotMan Widget</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/botman-web-widget/build/assets/css/chat.min.css">
</head>
<body>
<script id="botmanWidget" src='https://cdn.jsdelivr.net/npm/botman-web-widget/build/js/chat.js'></script>
</body>
</html><?php /**PATH /Users/limhalim/Desktop/Laravel-10-roles-and-permissions/vendor/botman/driver-web/src/Providers/../Laravel/views/chat.blade.php ENDPATH**/ ?>