<?php $__env->startSection('content-header'); ?>
    <h1>Edit Hero Section</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="box">
            <div class="box-body">
                <form action="<?php echo e(route('dashboard.home-hero-section.update', $heroSection->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="form-group">
                        <label for="head_text">Head Text</label>
                        <input type="text" name="head_text" id="head_text" class="form-control" value="<?php echo e($heroSection->head_text); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="title_text">Title Text</label>
                        <input type="text" name="title_text" id="title_text" class="form-control" value="<?php echo e($heroSection->title_text); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea name="description" id="description" class="form-control" required><?php echo e($heroSection->description); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="image">Image</label>
                        <input type="file" name="image" id="image" class="form-control">
                        <small>Current Image:</small>
                        <img src="<?php echo e(asset('images/home/home_hero_section/' . $heroSection->image)); ?>" alt="Image" width="100">
                    </div>

                    <button type="submit" class="btn btn-primary">Update</button>
                    <a href="<?php echo e(route('dashboard.home-hero-section.index')); ?>" class="btn btn-secondary">Cancel</a>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-layout-v2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/limhalim/Desktop/Laravel-10-roles-and-permissions/resources/views/home/home_hero_section/edit.blade.php ENDPATH**/ ?>