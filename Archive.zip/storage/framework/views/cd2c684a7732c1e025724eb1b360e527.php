<?php $__env->startSection('title', 'Edit About Company Section'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Edit About Company Section</h3>
            </div>
            <form action="<?php echo e(route('dashboard.about_company_section.update', $item->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="box-body">
                    <div class="form-group">
                        <label for="head_text">Head Text</label>
                        <input type="text" name="head_text" id="head_text" class="form-control" value="<?php echo e($item->head_text); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="description_text">Description Text</label>
                        <textarea name="description_text" id="description_text" class="form-control" rows="5" required><?php echo e($item->description_text); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="image_person">Image</label>
                        <input type="file" name="image_person" id="image_person" class="form-control">
                        <?php if($item->image_person): ?>
                            <img class="my-2" src="<?php echo e(asset('images/about/' . $item->image_person)); ?>" width="400" alt="Image">
                        <?php endif; ?>
                    </div>
                </div>
                <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-layout-v2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/limhalim/Desktop/Laravel-10-roles-and-permissions/resources/views/about/about_company_section/edit.blade.php ENDPATH**/ ?>