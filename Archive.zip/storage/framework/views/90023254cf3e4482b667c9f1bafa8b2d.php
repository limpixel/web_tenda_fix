<?php $__env->startSection('head'); ?>
    <style>
        #content__button{
            background: white;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="row">
        <!-- Kolom 1 -->
        <div class="col-md-4 col-sm-6 col-12 mb-3">
            <a id="content__button"  href="https://example.com/1" class="grid-link ">
                <div class="p-3 border bg-light text-center">Grid 1</div>
            </a>
        </div>
        <!-- Kolom 2 -->
        <div class="col-md-4 col-sm-6 col-12 mb-3">
            <a href="https://example.com/2" class="grid-link">
                <div class="p-3 border bg-light text-center">Grid 2</div>
            </a>
        </div>
        <!-- Kolom 3 -->
        <div class="col-md-4 col-sm-6 col-12 mb-3">
            <a href="https://example.com/3" class="grid-link">
                <div class="p-3 border bg-light text-center">Grid 3</div>
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard-layout-v2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/limhalim/Desktop/Laravel-10-roles-and-permissions/resources/views/home/home_dashboard.blade.php ENDPATH**/ ?>